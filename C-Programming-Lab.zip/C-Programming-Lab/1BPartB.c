// Write a program to print Hello World.

// (B) Program to print Hello World using new line character.

#include<stdio.h>
int main() {
    printf("Hello World.\nHello World.");
    return 0;
}