// Write a program to print Hello World.

// (C) Program to print Hello World using Tab Character

#include<stdio.h>
int main() {
    printf("Hello World.\tHello World.");
    return 0;
}