// Write a program to print Hello World

// (A) Program to print Hello World

#include<stdio.h>
int main() {
    printf("Hello World.");
    return 0;
}
